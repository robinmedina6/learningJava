/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.misiontic2021.ejerciciossemana3;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Club {
    private String nombreClub;
    private Socio socio1, socio2, socio3;
    private Scanner entrada;

    public Club(String nombreClub) {
        this.nombreClub = nombreClub;
        this.entrada = new Scanner(System.in);
        this.socio1 =new Socio(entrada);
        this.socio2 =new Socio(entrada);
        this.socio3 =new Socio(entrada);
    }

    public String getNombreClub() {
        return nombreClub;
    }
    
       public void MasAntiguo(){
           System.out.println("El socio mas antiguo del club "+this.getNombreClub()+" es:");
           if (socio1.getAntiguedad()>socio2.getAntiguedad()&&
             socio1.getAntiguedad()>socio3.getAntiguedad()){
               
               System.out.println(socio1.getNombre());
           } else{
           if (socio2.getAntiguedad()>socio3.getAntiguedad()){
                System.out.println(socio2.getNombre());
}else{
                System.out.println(socio3.getNombre());
           }
}
}
}
    


