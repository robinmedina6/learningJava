/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.misiontic2021.ejerciciossemana3;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Socio {
    String nombre;
    int antiguedad;

   
    public Socio(Scanner teclado) {
        System.out.println("Nombre Socio:");
        this.nombre=teclado.next();
        System.out.println("Antigüedad del Socio:");
        this.antiguedad =teclado.nextInt();
    }

    public String getNombre() {
        return nombre;
    }

    public int getAntiguedad() {
        return antiguedad;
    }


        
}
