/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.misiontic2021.ejerciciossemana3;

/**
 *
 * @author user
 */
public class Banco {
    private String nombreBanco, nombreEmpleado,apellidoEmpleado;
    private Empleado empleado[];

    public Banco(String nombreBanco, String nombreEmpleado, String apellidoEmpleado, int numEmp){
        this.nombreBanco = nombreBanco;
        this.nombreEmpleado=nombreEmpleado;
        this.apellidoEmpleado=apellidoEmpleado;
        this.empleado = new Empleado[numEmp];
        for(int i=0;i<numEmp;i++){
            this.empleado[i]= new Empleado(this.nombreEmpleado, this.apellidoEmpleado);
            
        }
    }
    public String NombreEmpleado(int numero){
         return this.empleado[numero].getNombre();
     }
 }
   