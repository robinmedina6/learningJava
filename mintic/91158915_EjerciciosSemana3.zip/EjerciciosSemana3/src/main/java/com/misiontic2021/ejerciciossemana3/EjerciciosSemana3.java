/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.misiontic2021.ejerciciossemana3;

import java.util.Arrays;

/**
 *
 * @author user
 */
public class EjerciciosSemana3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
    
//         Banco miBanco =new Banco("Banco Bucaramanga","Javier", "Quintero",3);
//         System.out.println(miBanco.NombreEmpleado(2));
//Empleado NuevEmpleado =new Empleado("Pepito", "perez");
//        System.out.println(NuevEmpleado.getApellido());
        Club NuevoClub =new Club("Club MINTIC");
        NuevoClub.MasAntiguo();

    }

}
