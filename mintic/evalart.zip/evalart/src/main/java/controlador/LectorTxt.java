/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import controlador.utilidades.Constantes;
import controlador.utilidades.Propert;
import controlador.utilidades.TipoLog;
import controlador.utilidades.UtilesLog;
import controlador.utilidades.Utilidades;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import logica.ClientFilter;

/**
 * Clase encargada de Leer el archivo de Filtros y cargarlo en la Logica con
 * estas condiciones
 *
 * @author robin_vfh49pm
 *
 */
public class LectorTxt {

    public LectorTxt() {

    }

    /**
     * Metodo encargado de Cargar el Archivo
     *
     * @author robin_vfh49pm
     * @return retona El bufferedReader listo para el procesamiento
     * @throws java.io.FileNotFoundException
     *
     */
    public BufferedReader cargarArchivo() throws FileNotFoundException, IOException {
        FileReader fr = null;
        BufferedReader br = null;
        Propert pr = new Propert();
        File f = new File(Utilidades.rutaActual() + pr.getProperty(Constantes.NOMBRE_ARCHIVO_TXT));
        fr = new FileReader(f);
        br = new BufferedReader(fr);
        return br;
    }

    /**
     * Metodo encargado de Colocar los parametros del archivo en la logica del Filtro
     *
     * @author robin_vfh49pm
     * @return retona El bufferedReader listo para el procesamiento
     * @throws java.io.FileNotFoundException
     *
     */
    public ArrayList<ClientFilter> cargarFiltros() throws IOException {
        BufferedReader br = cargarArchivo();
        String linea;
        ArrayList<String> aString = new ArrayList<String>();
        aString.add("<General>");
        aString.add("<Mesa 1>");
        aString.add("<Mesa 2>");
        aString.add("<Mesa 3>");
        aString.add("<Mesa 4>");
        aString.add("<Mesa 5>");
        aString.add("<Mesa 6>");
        String actual = aString.get(0);

        ArrayList<ClientFilter> filtros = new ArrayList<ClientFilter>();
        ClientFilter fl = null;
        while ((linea = br.readLine()) != null) {
            int index = aString.indexOf(linea);
            if (index >= 0) {
                actual = linea;
                if (fl != null) {
                    filtros.add(fl);
                }
                fl = new ClientFilter();
                fl.setNombreFiltro(actual);
            } else {
                String ln[] = linea.split(":");
                switch (ln[0]) {
                    case "TC":
                        fl.setType(Integer.parseInt(ln[1]));
                        break;
                    case "UG":
                        fl.setLocation(ln[1]);
                        break;
                    case "RI":
                        fl.setRangoInicial((BigDecimal) BigDecimal.valueOf(Double.parseDouble(ln[1])));
                        break;
                    case "RF":
                        fl.setRangoFinal((BigDecimal) BigDecimal.valueOf(Double.parseDouble(ln[1])));
                        break;
                    default:
                        UtilesLog.registrarInfo(this.getClass(), TipoLog.INFO, "default");
                        break;
                }
            }

        }
        filtros.add(fl);
        return filtros;
    }

}
