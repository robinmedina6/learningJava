/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import controlador.utilidades.TipoLog;
import controlador.utilidades.UtilesLog;
import static controlador.utilidades.UtilesLog.registrarInfo;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import logica.ClientDao;
import logica.ClientFilter;
import logica.PosibleGuest;
import logica.ResultFilter;
import logica.wsclients.EvalarClient;

/**
 * Clase Helper que enlaza la logica y las utilidades ejecuta toda la operacion
 *
 * @author robin_vfh49pm
 *
 */
public class Helper {

    /**
     * Metodo que ejecuta todo el proceso hace los llamados conrrespondientes
     *
     * @author robin_vfh49pm
     *
     */
    public boolean ejecutarProceso() {

        try {
            LectorTxt lc = new LectorTxt();
            ArrayList<ClientFilter> arrayFiltros = lc.cargarFiltros();
            ArrayList<ClientFilter> filtrosFinos = finarFiltros(arrayFiltros);
            ArrayList<ResultFilter> resultFilter = extraeClientBd(filtrosFinos);
            resultFilter = decriptClientCodesAndOrder(resultFilter);
            registrarInfo(this.getClass(), TipoLog.INFO, "Ordenando:" + resultFilter.toString());
            resultFilter = FilterCompanyAndSex(resultFilter);

            registrarInfo(this.getClass(), TipoLog.INFO, resultFilter.toString());
            registrarInfo(this.getClass(), TipoLog.INFO, "______________________________________________________________\nimprimiendo la Salida \n -------------------------------------------------------------------------");
            printTables(resultFilter);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    /**
     * Metodo para Arreglar los filtros, es decir les coloca las condiciones de
     * la mesa general ejecuta toda la operacion
     *
     * @author robin_vfh49pm
     * @param filtrosIniciales es la lista de filtros ya creada y a procesar
     * @return son los filtros ya procesados y arreglados
     *
     */
    public ArrayList<ClientFilter> finarFiltros(ArrayList<ClientFilter> filtrosIniciales) {
        ClientFilter primerFiltro = filtrosIniciales.get(0);
        for (ClientFilter el : filtrosIniciales) {
            if (0 == el.getType()) {
                el.setType(primerFiltro.getType());
            }
            if (null == el.getLocation()) {
                el.setLocation(primerFiltro.getLocation());
            }
            if (null == el.getRangoInicial()) {
                el.setRangoInicial(primerFiltro.getRangoInicial());
            }
            if (null == el.getRangoFinal()) {
                el.setRangoFinal(primerFiltro.getRangoFinal());
            }
        }
        return filtrosIniciales;
    }

    /**
     * Metodo para hacer la consulta en base de datos de cada uno de los filtros
     *
     * @param filtrosListos como entrada es un arrayList<ClientFilter> trae cada
     * objeto con las condiciones del filtro
     * @author robin_vfh49pm
     * @return devuelve los filtros procesados y con los resultados
     *
     */
    public ArrayList<ResultFilter> extraeClientBd(ArrayList<ClientFilter> filtrosListos) {
        ArrayList<ResultFilter> afr = new ArrayList<ResultFilter>();
        ResultFilter fr;
        ClientDao cd = new ClientDao();
        for (ClientFilter el : filtrosListos) {
            fr = new ResultFilter();
            fr.setNombreFiltro(el.getNombreFiltro());
            fr.setRangoFinal(el.getRangoFinal());
            fr.setRangoInicial(el.getRangoInicial());
            fr.setArrayPosibleGuest(cd.getPosibleGuest(el));
            UtilesLog.registrarInfo(this.getClass(), TipoLog.INFO, fr.getArrayPosibleGuest().toString());

            afr.add(fr);
        }
        return afr;
    }

    /**
     * Metodo para traer la des encriptar el codigo del cliente y ordenar de
     * nuevo la lista teniendo en cuenta este nuevo parametro
     *
     * @author robin_vfh49pm
     * @param listaFiltroResultado lista de filtro resultado a procesar para
     * desencripar
     * @return devuelve la lista procesada y desencriptada y ordenada teniendo
     * en cuenta el codigo
     *
     */
    public ArrayList<ResultFilter> decriptClientCodesAndOrder(ArrayList<ResultFilter> listaFiltroResultado) {
        for (ResultFilter rf : listaFiltroResultado) {
            for (PosibleGuest pg : rf.getArrayPosibleGuest()) {
                if (1 == pg.getEncrypt()) {
                    EvalarClient ec = new EvalarClient();
                    pg.setCode(ec.decryptCode(pg.getCode()));
                }
            }
            BigDecimal lastSumBalance = null;
            ArrayList<String> arrayCodes = new ArrayList<String>();
            ArrayList<Integer> arrayIndex = new ArrayList<Integer>();
            ArrayList<PosibleGuest> arrayPosibleGuests = new ArrayList<PosibleGuest>();
            for (PosibleGuest pg : rf.getArrayPosibleGuest()) {
                if (lastSumBalance == pg.getSumBalance()) {
                    arrayCodes.add(pg.getCode());
                    arrayIndex.add(rf.getArrayPosibleGuest().indexOf(pg));
                    arrayPosibleGuests.add(pg);
                }
                lastSumBalance = pg.getSumBalance();
            }
            Collections.sort(arrayPosibleGuests, new Comparator<PosibleGuest>() {
                public int compare(PosibleGuest spg1, PosibleGuest spg2) {
                    return spg1.getCode().compareToIgnoreCase(spg2.getCode());
                }
            });

            int cntIndex = 0;
            for (Integer index : arrayIndex) {
                rf.getArrayPosibleGuest().set(index, arrayPosibleGuests.get(cntIndex));
                cntIndex++;
            }
        }

        return listaFiltroResultado;
    }

    /**
     * Metodo para quitar Compañias Repetidas y Quitar generos que no deberian
     * estar en la mesa
     *
     * @param listaFiltroResultado son los resultados del filtro a procesar para
     * retirar compañias repetidas y generos no acordes
     * @author robin_vfh49pm
     * @return son los filtros devueltos procesado sin empresas ni generos
     * erronreos
     */
    public ArrayList<ResultFilter> FilterCompanyAndSex(ArrayList<ResultFilter> listaFiltroResultado) {
        //ArrayList<ResultFilter> arfn = listaFiltroResultado;
        for (ResultFilter rf : listaFiltroResultado) {
            ArrayList<String> empresas = new ArrayList<String>();
            int male = 0;
            int female = 0;
            for (int i = 0; i < rf.getArrayPosibleGuest().size(); i++) {
                PosibleGuest pg = rf.getArrayPosibleGuest().get(i);
                if (empresas.indexOf(pg.getCompany()) >= 0) {
                    registrarInfo(this.getClass(), TipoLog.INFO, rf.getNombreFiltro() + " Elimiando por Compañia ya Existe: " + pg.toString());
                    rf.getArrayPosibleGuest().remove(pg);
                    i--;
                    continue;
                }
                empresas.add(pg.getCompany());
                if (pg.getMale() > 0) {
                    male++;
                } else {
                    female++;
                }
            }

            int min = 0;
            if (male < female) {
                min = male;
            } else {
                min = female;
            }
            if (min > 4) {
                min = 4;
            }

            int cntMale = 0, cntFemale = 0;
            for (int i = 0; i < rf.getArrayPosibleGuest().size(); i++) {
                if(i>7){break;}
                PosibleGuest pg = rf.getArrayPosibleGuest().get(i);
                if (cntFemale >= min && pg.getMale() == 0) {
                    registrarInfo(this.getClass(), TipoLog.INFO, rf.getNombreFiltro() + "Elimiando por mujer y ya hay : " + rf.getNombreFiltro() + pg.toString());
                    rf.getArrayPosibleGuest().remove(pg);
                    i--;
                    continue;
                }
                if (cntMale >= min && pg.getMale() == 1) {
                    registrarInfo(this.getClass(), TipoLog.INFO, rf.getNombreFiltro() + "Elimiando por hombre y ya hay: " + rf.getNombreFiltro() + pg.toString());
                    rf.getArrayPosibleGuest().remove(pg);
                    i--;
                    continue;
                }
                if (pg.getMale() > 0) {
                    cntMale++;
                } else {
                    cntFemale++;
                }
            }

        }
        return listaFiltroResultado;
    }

    /**
     * Metodo para Imprimir las mesas solicitadas en logs y limpias para pasar a
     * prueba
     *
     * @author robin_vfh49pm
     * @param resultFilter son los resultados a imprimir
     */
    public void printTables(ArrayList<ResultFilter> resultFilter) {
        for (int i = 0; i < resultFilter.size(); i++) {
            registrarInfo(this.getClass(), TipoLog.INFO, resultFilter.get(i).getNombreFiltro());
            StringBuilder codigos = new StringBuilder();
            String strfinal = ",";
            int cntItems = 0;
            if (resultFilter.get(i).getArrayPosibleGuest().size() < 4) {
                cntItems = 0;
                codigos.append("CANCELADA");
            } else if (resultFilter.get(i).getArrayPosibleGuest().size() <= 8) {
                cntItems = resultFilter.get(i).getArrayPosibleGuest().size();
            } else if (resultFilter.get(i).getArrayPosibleGuest().size() > 8) {
                cntItems = 8;
            }

            for (int j = 0; j < cntItems; j++) {
                codigos.append(resultFilter.get(i).getArrayPosibleGuest().get(j).getCode());
                if (j < cntItems - 1) {
                    codigos.append(strfinal);
                }
            }
            registrarInfo(this.getClass(), TipoLog.INFO, codigos.toString());

        }
        registrarInfo(this.getClass(), TipoLog.INFO, "_________________Impresion Limpia No Logs_______________________");
        for (int i = 0; i < resultFilter.size(); i++) {
            System.out.println(resultFilter.get(i).getNombreFiltro());
            StringBuilder codigos = new StringBuilder();
            String strfinal = ",";
            int cntItems = 0;
            if (resultFilter.get(i).getArrayPosibleGuest().size() < 4) {
                cntItems = 0;
                codigos.append("CANCELADA");
            } else if (resultFilter.get(i).getArrayPosibleGuest().size() <= 8) {
                cntItems = resultFilter.get(i).getArrayPosibleGuest().size();
            } else if (resultFilter.get(i).getArrayPosibleGuest().size() > 8) {
                cntItems = 8;
            }

            for (int j = 0; j < cntItems; j++) {
                codigos.append(resultFilter.get(i).getArrayPosibleGuest().get(j).getCode());
                if (j < cntItems - 1) {
                    codigos.append(strfinal);
                }
            }
            System.out.println(codigos);

        }
    }
}
