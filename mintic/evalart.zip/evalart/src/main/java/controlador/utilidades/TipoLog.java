/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.utilidades;

/**
 * clase de enumeracion con los tipos de Log
 * @author robin_vfh49pm
 */
public enum TipoLog {

 DEBUG, ERROR, FATAL, INFO, WARNING
}
