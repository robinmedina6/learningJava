/*
 * To change this license header, choose License Headers in Project Propert.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.utilidades;

import static controlador.utilidades.UtilesLog.registrarInfo;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

/**
 *clase que permite obtener las propiedades de un archivo configurador
 * @author robin_vfh49pm
 */
public class Propert {

    Properties misPropiedades;
    File f;

    public Propert() {
        misPropiedades = new Properties();
        misPropiedades = cargar();
    }

    public void listarArchivo() {
        misPropiedades.list(System.out);
    }

    public void mostrarDatos() {
        String nombre = misPropiedades.getProperty("bd.user");
        System.out.println(nombre);
    }
  /**
     * El metodo devuelve la propiedad buscada en archivo 
     *
     * @author robin_vfh49pm
     * @param key es la llave String con el nombre de la propiedad
     * @return retorna string con el valor de la propiedad
     *
     */
    public String getProperty(String key) {
        String rta = misPropiedades.getProperty(key);;
        return rta;
    }
  /**
     * Metodo encargado de Cargar el archivo de propiedades
     *
     * @author robin_vfh49pm
     * @return  retorna una instancia de la clase properties
     *
     */
    public Properties cargar() {
        try {
            String ruta = System.getProperty(Constantes.PROPERTY_USER_DIR) + Constantes.PROPERTY_FILE;
            FileInputStream archivo = new FileInputStream(ruta);
            Properties propiedades = new Properties();
            propiedades.load(archivo);
            archivo.close();
            if (!propiedades.isEmpty()) {
                return propiedades;
            }

        } catch (Exception e) {
            registrarInfo(Propert.class, TipoLog.INFO, "No se pudo cargar el archivo properties");
        }
        return null;
    }

}
