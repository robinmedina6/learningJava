/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.utilidades;

/**
 * Clase Encargada de entregar utilidades que se pueden utilizar en otras clases
 * como entregar rutas y fechas repetitivas
 *
 * @author robin_vfh49pm
 */
public class Utilidades {

    /**
     * el Metodo devuelve la ruta de la propiedad configurada PROPERTY_USER_DIR
     *
     * @author robin_vfh49pm
     * @return devuelve el valor de la propiedad en valor String
     */
    public static String rutaActual() {
        return System.getProperty(Constantes.PROPERTY_USER_DIR);
    }
}
