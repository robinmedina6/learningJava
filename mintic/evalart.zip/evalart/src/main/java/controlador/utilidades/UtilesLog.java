/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.utilidades;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 * clase que se encarga de cargar logs e imprimir esto permite guardar la salida
 * del programa en el archivo log
 *
 * @author robin_vfh49pm
 */
public class UtilesLog {

    private static Logger log = Logger.getLogger(UtilesLog.class);
    private static boolean flagPropCargadas = false;

    /**
     * metodo que se encarga de cargar las propiedades para la configuracion de
     * los logs
     *
     * @author robin_vfh49pm
     */
    public static void cargarProperties() {

        String ruta = Utilidades.rutaActual() + Constantes.PROPERTY_LOG_FILE;
        PropertyConfigurator.configure(ruta);
    }

    /**
     * el metodo se encarga de colocar informacion en la instancia del log
     * salida del programa en el archivo log
     *
     * @author robin_vfh49pm
     * @param clase corresponde a la clase que envia el mensaje
     * @param tipo corresponde al tipo de Log si es Informacion Error u otros
     * @param mensaje corresponde al mensaje tipo String
     */
    public static void registrarInfo(Class clase, TipoLog tipo, String mensaje) {
        if (!flagPropCargadas) {
            cargarProperties();
        }
        log = LogManager.getLogger(clase);
        switch (tipo) {
            case DEBUG:
                log.debug(mensaje);
                break;
            case ERROR:
                log.error(mensaje);
                break;
            case FATAL:
                log.fatal(mensaje);
                break;
            case INFO:
                log.info(mensaje);
                break;
            case WARNING:
                log.warn(mensaje);
        }
    }
}
