/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.utilidades;

/**
 *clase con las Constantes Definidas de rutas de archivos y propiedades
 * @author robin_vfh49pm
 */
public class Constantes {
    public static final String PROPERTY_USER_DIR = "user.dir";
    public static final String PROPERTY_FILE ="/config.properties";
    public static final String PROPERTY_LOG_FILE ="/log4j.properties";
    public static final String NOMBRE_ARCHIVO_TXT = "nombre.archivo.txt";
    public static final String WS_URL = "ws.url";
    
    
}
