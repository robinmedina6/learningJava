package controlador;

import controlador.utilidades.TipoLog;
import static controlador.utilidades.UtilesLog.registrarInfo;

/**
 * Metodo Main ejecucion
 *
 * @author robin_vfh49pm
 *
 */
public class Principal {

    /**
     * @param args
     */
    public static void main(String[] args) {
        registrarInfo(Principal.class, TipoLog.INFO, "Iniciando Logs....");
        Helper hp = new Helper();
        hp.ejecutarProceso();
    }

}
