/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *clase que representa la Logica del cliente del banco
 * con sus propiedades
 * @author robin_vfh49pm
 */
public class Client {

    protected int id;
    protected String code;
    protected int male;
    protected int type;
    protected String location;
    protected String company;
    protected int encrypt;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getMale() {
        return male;
    }

    public void setMale(int male) {
        this.male = male;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getEncrypt() {
        return encrypt;
    }

    public void setEncrypt(int encrypt) {
        this.encrypt = encrypt;
    }

    @Override
    public String toString() {
        return "Client{" + "id=" + id + ", code=" + code + ", male=" + male + ", type=" + type + ", location=" + location + ", company=" + company + ", encrypt=" + encrypt + '}';
    }
    
}