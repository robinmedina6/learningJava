/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import java.math.BigDecimal;

/**
 * Clase tipo Logica que contiene las propiedades especificas del Filtro para Cliente
 * es decir son las condiciones especificas para una mesa extiende de la clase  Cliente
 * @author robin_vfh49pm
 */
public class ClientFilter extends Client{
     private String nombreFiltro;
    private BigDecimal rangoInicial;
    private BigDecimal rangoFinal;

    public String getNombreFiltro() {
        return nombreFiltro;
    }

    public void setNombreFiltro(String nombreFiltro) {
        this.nombreFiltro = nombreFiltro;
    }
   

    
    public BigDecimal getRangoInicial() {
        return rangoInicial;
    }

    public void setRangoInicial(BigDecimal rangoInicial) {
        this.rangoInicial = rangoInicial;
    }

    public BigDecimal getRangoFinal() {
        return rangoFinal;
    }

    public void setRangoFinal(BigDecimal rangoFinal) {
        this.rangoFinal = rangoFinal;
    }

    @Override
    public String toString() {
        return "FiltroClient{ " + super.toString() + "nombreFiltro=" + nombreFiltro + ", rangoInicial=" + rangoInicial + ", rangoFinal=" + rangoFinal + '}';
    }

   
    
    
    
}
