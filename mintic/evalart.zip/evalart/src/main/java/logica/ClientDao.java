package logica;

import controlador.utilidades.TipoLog;
import controlador.utilidades.UtilesLog;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.ArrayList;

/**
 * Clase que permite el acceso a la base de datos desde la logica de Cliente
 * consultas especificas
 *
 * @author robinson
 *
 */
public class ClientDao {

    public ClientDao() {

    }

    public ArrayList<PosibleGuest> getPosibleGuest(ClientFilter el) {

        ArrayList<PosibleGuest> apg = new ArrayList<PosibleGuest>();

        PosibleGuest pg ;

        Conexion conex = new Conexion();
        Connection cnx = conex.getConnection();
        String sql = "SELECT  c.* , a.*"
                + " FROM  `client` AS c INNER JOIN ("
                + "SELECT SUM(a.balance) AS sum_balance ,a.client_id  "
                + "FROM  `account` AS a "
                + "GROUP BY a.client_id) AS a "
                + "ON a.client_id=c.id WHERE 1=1 ";

        if (0 != el.getType()) {
            sql += "AND c.type = " + el.type + " ";
        }
        if (null != el.getLocation()) {
            sql += "AND c.location = " + el.location + " ";
        }
        if (null != el.getRangoInicial()) {
            sql += "AND a.sum_balance >= " + el.getRangoInicial() + " ";
        }
        if (null != el.getRangoFinal()) {
            sql += "AND a.sum_balance <= " + el.getRangoFinal() + " ";
        }
        sql += " ORDER BY a.sum_balance DESC,c.code  ASC ";
        UtilesLog.registrarInfo(this.getClass(), TipoLog.INFO, el.getNombreFiltro() + "|" + sql);
        try {
            PreparedStatement pstmt = cnx.prepareStatement(sql);
            ResultSet rs = null;
            boolean success = true;
            try {
                rs = pstmt.executeQuery();
                while (rs.next()) {
                    pg = new PosibleGuest();
                    pg.setId(rs.getInt("id"));
                    pg.setCode(rs.getString("code"));
                    pg.setMale(rs.getInt("male"));
                    pg.setType(rs.getInt("type"));
                    pg.setLocation(rs.getString("location"));
                    pg.setCompany(rs.getString("company"));
                    pg.setEncrypt(rs.getInt("encrypt"));
                    pg.setSumBalance(rs.getBigDecimal("sum_balance"));
                    apg.add(pg);
                }
            } catch (SQLException e) {
                UtilesLog.registrarInfo(this.getClass(), TipoLog.ERROR, "excepcion:" + e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
                success = false;
            } finally {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (cnx != null) {
                    cnx.close();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return apg;
    }

}
