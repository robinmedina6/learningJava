/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Clase Tipo logica que respresenta El Filtro ya con los resultados del mismo
 * es decir que aqui se guarda la informacion que comprende un filtro aplicado incluyendo los posibles clientes
 * @author robin_vfh49pm
 */
public class ResultFilter {
    private String nombreFiltro;
    private BigDecimal rangoInicial;
    private BigDecimal rangoFinal;
    
    private ArrayList<PosibleGuest> arrayPosibleGuest;

    public ArrayList<PosibleGuest> getArrayPosibleGuest() {
        return arrayPosibleGuest;
    }

    public void setArrayPosibleGuest(ArrayList<PosibleGuest> selectedClients) {
        this.arrayPosibleGuest = selectedClients;
    }
    
    

    public String getNombreFiltro() {
        return nombreFiltro;
    }

    public void setNombreFiltro(String nombreFiltro) {
        this.nombreFiltro = nombreFiltro;
    }
   

    
    public BigDecimal getRangoInicial() {
        return rangoInicial;
    }

    public void setRangoInicial(BigDecimal rangoInicial) {
        this.rangoInicial = rangoInicial;
    }

    public BigDecimal getRangoFinal() {
        return rangoFinal;
    }

    public void setRangoFinal(BigDecimal rangoFinal) {
        this.rangoFinal = rangoFinal;
    }

    @Override
    public String toString() {
        return "ResultFilter{" + "nombreFiltro=" + nombreFiltro + ", rangoInicial=" + rangoInicial + ", rangoFinal=" + rangoFinal + ", arrayPosibleGuest=" + arrayPosibleGuest + '}';
    }

   
    
    
}
