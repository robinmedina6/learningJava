/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import java.math.BigDecimal;

/**
 *clase Tipo logica que contiene las propiedades de los posibles clientes seleccionados para la mesa
 * extiende de la clase cliente
 * @author robin_vfh49pm
 */
public class PosibleGuest extends Client{
    private BigDecimal sumBalance;

    public BigDecimal getSumBalance() {
        return sumBalance;
    }

    public void setSumBalance(BigDecimal sumBalance) {
        this.sumBalance = sumBalance;
    }

    @Override
    public String toString() {
        return "PosibleGuest{"+super.toString() + " sumBalance=" + sumBalance + '}';
    }


   
    
    
    
}
