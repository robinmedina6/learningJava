/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica.wsclients;

import controlador.utilidades.Constantes;
import controlador.utilidades.Propert;
import controlador.utilidades.TipoLog;
import controlador.utilidades.UtilesLog;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Esta Clase es la implementacion para el consumo del WS
 * se implementa muy sencillo teniendo en Cuenta la aplicacion del caso
 * @author robin_vfh49pm
 */
public class EvalarClient {

    public String decryptCode(String code) {
        String output = "";
        String htmlCode = "";
        try {
            Propert pr = new Propert();
            URL url = new URL(pr.getProperty(Constantes.WS_URL) + code);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Fallo : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            while ((output = br.readLine()) != null) {
                UtilesLog.registrarInfo(this.getClass(), TipoLog.INFO, "me responde: " + output);
                htmlCode= output;
            }
            conn.disconnect();

        } catch (Exception e) {
            UtilesLog.registrarInfo(this.getClass(), TipoLog.INFO, e.getStackTrace().toString());
        }
        htmlCode = htmlCode.substring(1, htmlCode.length() - 1);
        UtilesLog.registrarInfo(this.getClass(), TipoLog.INFO, "Extract substring:" + htmlCode);
        return htmlCode;
    }
}
