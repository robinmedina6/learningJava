/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

import controlador.utilidades.Propert;
import controlador.utilidades.TipoLog;
import static controlador.utilidades.UtilesLog.registrarInfo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase que contiene la de conexion directa a BD
 *
 * @author robin_vfh49pm
 */
public class Conexion {

    static String bd = "";
    static String login = "";
    static String password = "";
    static String url = "";

    Connection conn = null;

    /**
     * Constructor de DbConnection
     */
    public Conexion() {
        Propert prop = new Propert();
        bd = prop.getProperty("bd.database");
        login = prop.getProperty("bd.user");
        password = prop.getProperty("bd.ctr");
        String host = prop.getProperty("bd.host");
        String port = prop.getProperty("bd.port");
        url = "jdbc:mysql://" + host + ":" + port + "/" + bd;
        try {
            conn = DriverManager.getConnection(url, login, password);
            if (conn != null) {
                registrarInfo(Conexion.class, TipoLog.INFO, "Conección a base de datos " + bd + " OK");
            }
        } catch (SQLException e) {
            registrarInfo(Conexion.class, TipoLog.INFO, e.getMessage());
        } catch (Exception e) {
            registrarInfo(Conexion.class, TipoLog.INFO, e.getMessage());
        }
    }

    /**
     * Permite retornar la conexión
     *
     * @return retorna Objeto tipo conexion para ser procesado
     */
    public Connection getConnection() {
        return conn;
    }

    /**
     * hace la Desconexion
     *
     */
    public void desconectar() {
        conn = null;
    }

}
